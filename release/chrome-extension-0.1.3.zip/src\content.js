// Content script placeholder: not required for popup-only functionality
// You can add DOM manipulation code here if you later want to inject jokes into pages.

console.log('Content script placeholder loaded');
