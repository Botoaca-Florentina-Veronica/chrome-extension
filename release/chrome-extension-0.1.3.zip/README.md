# Chrome Extension: Jokes, Quotes & Memes

A fun Chrome extension that displays random jokes, motivational quotes, and memes (in the future). Features an animated camel that walks across your screen pulling a quote banner!

![Extension preview](assets/image.png)

Link to chrome web store:
https://chromewebstore.google.com/detail/aknckelgghnbkcoabpmfkdphgngmpnej?utm_source=item-share-cb